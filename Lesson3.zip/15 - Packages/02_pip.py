# pip install opencv
# pip install numpy
# pip install xlrd
# mac安裝請用pip3 install
# https://pypi.org/

# import tensorflow as tf(別名)

# pip3 --version
# pip3 list

