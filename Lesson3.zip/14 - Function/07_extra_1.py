# 定義一個方程式sequential_add
# 方程式有兩個參數 n1 n2
# 算出n1 - n2之間數字的加總
# 印出結果在terminal
# 注意：不可以使用print

# 例子
# sequential_add(1,10) -> 回傳55
# sequential_add(5,10) -> 回傳45
# sequential_add(10,1000)-> 回傳500455