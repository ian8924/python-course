def multiply(num1, num2=10):
    total = num1 * num2
    return total

x = 5
y = 6
# 沒有輸入num2，則會使用default值10
z = multiply(5)
print(z)

# mini challenge
# 寫一個算出兩個數的平均的方程式