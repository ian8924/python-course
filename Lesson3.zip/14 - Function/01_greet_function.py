# 在我們還沒有function之前
company1 = 'Google'
company2 = 'Facebook'
company3 = 'Apple'

# wish1 = 'I want to work at Google'
# wish2 = 'I want to work at Facebook'
# wish3 = 'I want to work at Apple'

# print(wish1)
# print(wish2)
# print(wish3)

# 用function來讓code變得更簡潔
def make_wish(company='LinkedIn'):
    print(f'I want to work at {company}')

# make_wish(company1)
# make_wish(company2)
# make_wish(company3)
make_wish()

