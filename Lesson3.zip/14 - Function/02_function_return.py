def multiply1(num1, num2):
    total = num1 * num2
    print(total)

def multiply2(num1, num2):
    total = num1 * num2
    return 'Aloha'

def multiply3(num1, num2):
    total = num1 * num2
    return total

result = multiply1(5,6)
print(result)
#new_answer = result + 1
#print(new_answer)