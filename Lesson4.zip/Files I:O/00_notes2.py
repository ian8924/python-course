# 寫入檔案
# 檔案物件.write(字串)
# 換行
# 檔案物件.write('這是第一行\n這是第二行')
# 寫入JSON格式
# import json
# json.dump(寫入的資料, 檔案物件)

# 關閉檔案
# 目的：釋放資源
# 檔案物件.close()

# with open(檔案路徑,mode=開啟模式) as 檔案物件:
#   讀取或寫入檔案
# 可以自動關閉檔案 

