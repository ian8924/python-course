# 寫入檔案
# 創建一個number.txt的檔案
# 一行一行寫入 10 20 30 40 50

# 讀取檔案
# 讀取number.txt的文字
# 並且印出來

# 讀取number.txt檔案每一行，並且把數字加總起來
# 印出加總
# hint: for loop!
    