country = input('Which country were you born: ')
if country.lower() == 'taiwan':
	print('Covid safe')
if country.lower() == 'us':
	print('Covid alert')
if country.lower() == 'japan':
	print('Covid watch list')