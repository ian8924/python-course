# 要求使用者輸入名字
# 如果字首是A或B或C開頭
# 被分配到房間ABC(Room ABC)
# 如果字首是D開頭
# 被分配到房間D(Room D)
# 如果都不是，要求使用者輸入他們的姓
# 如果字首是Y或Z開頭，被分配到房間YZ(Room YZ)
# 如果都不是，被分配到房間Other(Room Other)