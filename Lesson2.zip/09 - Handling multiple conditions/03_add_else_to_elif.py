country = input('Which country were you born: ')
if country.lower() == 'taiwan':
	print('Covid safe')
elif country.lower() == 'us':
	print('Covid alert')
elif country.lower() == 'japan':
	print('Covid watch list')
else:
	print('Covid status unknown')