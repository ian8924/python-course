# if 布林(boolean) 條件一為True: 
# (Tab縮排)執行命令
# elif 布林(boolean) 條件二為True: 
# (Tab縮排)執行命令
# else: 
# (Tab縮排)執行命令
