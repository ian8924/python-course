country = input('Which country were you born: ')
if country == 'Taiwan':
	# 字串的比較是case sensitive
	print('Taiwan No.1!')
else:
	print('Sad!')
