country = input('Which country were you born: ')
# 使用string function來做字串轉換
if country.lower() == 'taiwan':
	print('Taiwan No.1!')
else:
	print('Sad!')
