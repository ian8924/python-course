age = 18
if age >= 18:
	discount = 0.1
else:
	discount = 0
# print()在if/else判斷之外
# 會被執行
print('Your discount rate is ' + discount)
