import math

math.sqrt(3,3)