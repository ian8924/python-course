name_one = 'Alice'
name_two = 'Yang'
if name_one == name_two
    print('Equal')
else
    print('Not Equal')