x = 8
y = 0

print(x / y)