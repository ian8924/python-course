x = 3
y = 6
while x < y:
	print(f'x is {x} and y is {y}')
	x = x + 1

# 無限循環迴圈(infinite loop)
n = 1
while True:
	print(n)
	n = n +1

# 寫一個會停下來的while loop吧！

