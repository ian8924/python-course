# for loop
# for 變數 in  集合(ex 列表(List), 字串(String)):
# 	將列表中的項目或是字串中的字元
# 	逐一處理

# while loop
# while 布林值 :
# 	若布林值為True，執行命令
# 	回到while迴圈，進行下一次的迴圈判斷

# 兩者差別在於
# For loops為Definite Loop，事先知道執行幾次的迴圈
# While loop為Indefinite Loop，事先不知道執行幾次的迴圈