# 利用while loop計算1加到10
# 利用for loop計算1加到10
