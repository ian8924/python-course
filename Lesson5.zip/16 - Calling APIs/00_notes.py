# 取得特定網址資料
# import urllib.request as request
# with request.urlopen(網址) as response:
#   data = response.read()