# print 可使用單引號
print('Hello world single quotes')

# print 可使用雙引號
print("Hello world double quotes")

# 但是請統一，不要混用
print('This is an apple")