# 請指出以下code錯誤的部分

# 1
print('Why won't this line of code print')

# 2
prnit('This line fails too!')

# 3
print "I think I know how to fix this one"

# 4
input('Please tell me your name: ')
print(name)
