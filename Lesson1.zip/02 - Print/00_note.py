# 常用快捷指令
# clear: 清除terminal的指令/ Window可用cls

# VS Code 儲存
# windows: ctrl + s 
# mac: command + s
# run code: 右上角箭頭符號 or Ctrl+Alt+N