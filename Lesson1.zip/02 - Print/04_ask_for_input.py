# Python input(輸入) 函式取得使用者的輸入，input()可以指定提示文字，使用者輸入的文字則以字串(string)傳回
# 你必須使用變數(variable)來儲存使用者輸入的文字
name = input('What is your name? ')
print('Hello! ' + name)

food = input('What is your favorite food? ')

print('Your favorite food is ' + food)

# mini challenge
# 印出你最想去的國家