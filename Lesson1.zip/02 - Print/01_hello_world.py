# Hello World! 你的第一行程式碼 :)
print('Hello world')
