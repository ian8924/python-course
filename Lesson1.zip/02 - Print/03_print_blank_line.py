# 每個print指令都從一的一行開始
print('Hello world')

# 如果你只打print()，會出現一行空白
print()
print('有看到上面一行是空白嗎')

# '\n' 是用來代表下一行
# 你可以用 '\n' 來分隔多行文字
print('我是 \n換行線\n換行線')



