# 註解可以用來 debug
print('Hello world')
print('It's a small world after all')
