# 如果字串裡有單引號(')的字
# print指令必須用雙引號("")
print("It's a small world after all")
