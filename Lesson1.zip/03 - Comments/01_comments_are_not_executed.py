# 我是註解
# print('Hello world')
# print("Hello world")
# 不會有任何output

# 為什麼我們需要寫註解
