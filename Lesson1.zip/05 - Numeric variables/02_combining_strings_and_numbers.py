three_thousand = 3000

# 你可以在 print() 裡面放字串或是數字
print(three_thousand)
print('I love you')

# 你可以使用 + 去相加兩個數字，或是把兩個字串結合
# 但是如果你用 + 去結合一個數字和一個字串
# 這行程式碼便會報錯
# print('I love you' + three_thousand)

# 你必須使用 str() 將數字轉化成字串
print('I love you ' + str(three_thousand))

