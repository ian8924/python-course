# 由於你將變數用數字賦值
# Python將會知道這是數字
first_num = 6
print(type(first_num))
second_num = 2

# 你可以對數字作常見的運算
print('兩數相加')
print(first_num + second_num)
print('兩數相減')
print(first_num - second_num)
print('兩數相乘')
print(first_num * second_num)
print('兩數相除')
print(first_num / second_num)
print ('指數')
print(first_num ** second_num)
