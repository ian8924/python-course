name = 'Alice'

print(name[0])
print(name[3])
# 會印出相同的結果
print(name[0:4])
print(name[:4])

# # 會印出相同的結果
print(name[0:5])
print(name[0:])
print(name[:])
