# 你可以使用加號(+)來連結兩個字串
first_name = 'Alice'
last_name = 'Yang'
print(first_name + last_name)

# 你也可以直接在使用' '來代表空格
print('Hello ' + first_name + ' ' + last_name)
