# 你可以將字串存在一個變數裡
first_name = 'Alice'
country_of_birth = 'Taiwan'
description = '''Learn
Python is A
New Fashion'''

# 這個變數可以在之後的程式碼裡使用
print(first_name)
print(country_of_birth)
print(description)